
import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <span>All rights reserved 2023 by nikhil</span>
        </footer>
    </div>
  )
}

export default FooterComponent